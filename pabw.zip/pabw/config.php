<?php

$db_host = "localhost:3306";
$db_user = "uts";
$db_pass = "Satria04032000";
$db_name = "satriabu_";

$mysqli = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

try {
    //create PDO connection 
    $db = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
} catch (PDOException $e) {
    //show error
    die("Terjadi masalah: " . $e->getMessage());
}
